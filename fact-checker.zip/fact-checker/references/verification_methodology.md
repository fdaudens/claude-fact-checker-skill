# Verification Methodology

## Verification Status Categories

### TRUE
**Definition:** The claim is accurate and supported by reliable evidence.

**Criteria:**
- Supported by multiple high-quality sources
- Primary sources confirm the claim
- No significant contradictory evidence exists
- Context does not materially change the claim

**Confidence Levels:**
- **High Confidence:** Multiple peer-reviewed sources or primary sources
- **Medium Confidence:** Reliable secondary sources with good methodology
- **Low Confidence:** Single reliable source or indirect evidence

### FALSE
**Definition:** The claim is demonstrably incorrect.

**Criteria:**
- Contradicted by reliable evidence
- Based on misrepresentation or fabrication
- Lacks any credible supporting evidence
- Context reveals the claim to be misleading

**Confidence Levels:**
- **High Confidence:** Multiple sources debunk the claim; clear evidence of falsehood
- **Medium Confidence:** Contradicted by reliable sources; limited supporting evidence
- **Low Confidence:** Likely false but evidence is incomplete

### PARTIALLY TRUE
**Definition:** The claim contains elements of truth but is incomplete, misleading, or lacks important context.

**Criteria:**
- Core fact is accurate but missing crucial context
- Claim is technically true but misleading in presentation
- Some parts are accurate while others are not
- Truth depends on specific interpretation or framing

**Examples:**
- Statistics cited correctly but from outdated source
- Quote is accurate but taken out of context
- Claim is true for subset but generalized incorrectly

### UNVERIFIED
**Definition:** Insufficient evidence exists to confirm or deny the claim.

**Criteria:**
- No reliable sources found to support or contradict
- Claim is too vague or ambiguous to verify
- Sources conflict without clear resolution
- Evidence is unavailable or inaccessible

**Note:** Unverified does not mean false; it means verification is not currently possible.

### OPINION/SUBJECTIVE
**Definition:** The statement is a matter of opinion, prediction, or subjective judgment rather than verifiable fact.

**Examples:**
- "The best movie of the year"
- "This policy will be harmful"
- Future predictions
- Value judgments

**Note:** While opinions cannot be fact-checked, underlying factual premises can be verified.

## Confidence Level Guidelines

### High Confidence (85-100%)
**Requirements:**
- Multiple independent, highly reliable sources confirm
- Primary sources available
- Peer-reviewed research supports claim
- Expert consensus exists
- Recent information (for current events)

**Examples:**
- Peer-reviewed scientific studies with replication
- Official government statistics
- Court records and legal documents
- Multiple firsthand accounts

### Medium Confidence (60-84%)
**Requirements:**
- Reliable secondary sources support claim
- Some corroboration but gaps exist
- Expert opinion without full consensus
- Indirect evidence supports claim

**Examples:**
- Reputable news reports without primary source confirmation
- Single academic study without replication
- Expert testimony without peer review
- Circumstantial evidence

### Low Confidence (40-59%)
**Requirements:**
- Limited sources available
- Sources have moderate credibility
- Evidence is circumstantial or indirect
- Conflicting information exists

**Examples:**
- Single news report without corroboration
- Unnamed or anonymous sources
- Preliminary findings
- Historical claims with limited documentation

### Insufficient Evidence (<40%)
**Characteristics:**
- Very few or no reliable sources
- Highly speculative or based on rumor
- Sources lack credibility
- Too little information to make determination

## Credibility Scoring Methodology

### Source Credibility (40% weight)

**Peer-reviewed academic (90-100 points):**
- Published in high-impact journal
- Rigorous peer review
- Reputable institution

**Government/Official statistics (80-95 points):**
- Official government database
- Established methodology
- Transparent data collection

**Reputable news organization (70-85 points):**
- Editorial standards
- Fact-checking process
- Track record of accuracy

**Expert opinion (60-80 points):**
- Relevant credentials
- Independent expert
- Disclosed affiliations

**General news/blogs (30-60 points):**
- Variable credibility
- May lack fact-checking
- Potential biases

**Anonymous/unverified (0-30 points):**
- No attribution
- No verification possible
- High risk of inaccuracy

### Methodology Quality (30% weight)

**Excellent methodology (90-100 points):**
- Rigorous research design
- Large sample size
- Controlled conditions
- Statistical significance
- Replication studies

**Good methodology (70-89 points):**
- Sound research design
- Adequate sample size
- Clear methodology
- Appropriate controls

**Fair methodology (50-69 points):**
- Basic research approach
- Limited sample size
- Some methodological concerns
- Incomplete controls

**Poor methodology (0-49 points):**
- Flawed research design
- Insufficient data
- Biased sampling
- Lack of controls

### Recency (15% weight)

**Very recent (90-100 points):**
- Within last 6 months
- Highly relevant for current events
- Up-to-date information

**Recent (70-89 points):**
- 6 months to 2 years
- Still relevant for most topics
- Minor temporal concerns

**Moderately dated (50-69 points):**
- 2-5 years old
- May need updating
- Context may have changed

**Dated (0-49 points):**
- Over 5 years old
- Significant context changes
- Potentially outdated information

**Note:** Recency matters less for historical facts and more for statistics, policies, and current events.

### Corroboration (15% weight)

**Highly corroborated (90-100 points):**
- 5+ independent sources confirm
- Consensus across multiple domains
- No credible contradictions

**Well corroborated (70-89 points):**
- 3-4 independent sources confirm
- Some agreement across sources
- Minor contradictions on details

**Minimally corroborated (50-69 points):**
- 1-2 sources confirm
- Limited additional evidence
- Some conflicting information

**Uncorroborated (0-49 points):**
- Single source or no confirmation
- Conflicting information
- Lack of verification

## Overall Credibility Score Calculation

**Formula:**
Total Score = (Source Credibility × 0.40) + (Methodology × 0.30) + (Recency × 0.15) + (Corroboration × 0.15)

**Score Interpretation:**
- **90-100:** Highly reliable - Strong evidence from multiple excellent sources
- **80-89:** Very reliable - Good evidence from reputable sources
- **70-79:** Reliable - Adequate evidence with minor concerns
- **60-69:** Moderately reliable - Some concerns about evidence quality
- **50-59:** Questionable - Significant concerns about reliability
- **Below 50:** Unreliable - Insufficient or poor-quality evidence

## Special Considerations

### Statistical Claims
- Verify original data source
- Check for sampling methodology
- Look for margin of error
- Consider statistical significance
- Check for cherry-picking

### Medical/Health Claims
- Prioritize peer-reviewed medical journals
- Check for FDA approval (when relevant)
- Look for clinical trial data
- Consider consensus of medical community
- Be wary of anecdotal evidence

### Historical Claims
- Seek primary sources
- Cross-reference with historians
- Consider historiographical context
- Check archival records
- Note scholarly debates

### Political Claims
- Use nonpartisan fact-checkers
- Verify with official records
- Check for full context and quotes
- Compare multiple news sources
- Note partisan framing

### Scientific Claims
- Look for peer review
- Check for replication studies
- Verify methodology
- Consider scientific consensus
- Note any conflicts of interest

### Breaking News
- Use extra caution with very recent claims
- Verify with multiple sources
- Note when information is developing
- Flag preliminary information
- Update as more information becomes available

## Context Assessment

**Critical Context Elements:**
1. **Timing:** When did the event occur or statement was made?
2. **Full quote:** Is the quote complete or taken out of context?
3. **Methodology:** How was data collected or conclusion reached?
4. **Scope:** Does the claim overgeneralize or oversimplify?
5. **Causation vs correlation:** Is causality inappropriately claimed?
6. **Comparison:** Are comparisons fair and appropriate?
7. **Definition:** Are terms used consistently and appropriately?

## Common Verification Pitfalls

### Avoid:
- Accepting first source without verification
- Ignoring publication date
- Missing important context
- Overlooking conflicts of interest
- Failing to check primary sources
- Cherry-picking supporting evidence
- Ignoring credible contradictory evidence
- Conflating correlation with causation
- Over-relying on single source type

### Best Practices:
- Cross-reference multiple independent sources
- Seek primary sources when possible
- Check author credentials and affiliations
- Verify publication reputation
- Consider recency and relevance
- Look for peer review
- Check for replication
- Assess methodology
- Consider broader context
- Flag uncertainties clearly
