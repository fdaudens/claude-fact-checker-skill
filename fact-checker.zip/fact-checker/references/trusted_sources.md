# Trusted Sources for Fact-Checking

## Academic and Research Databases

### Primary Sources (Highest Credibility)
- **Google Scholar** (scholar.google.com) - Comprehensive academic search engine
- **PubMed** (pubmed.ncbi.nlm.nih.gov) - Biomedical and life sciences literature
- **arXiv** (arxiv.org) - Preprints in physics, mathematics, computer science
- **JSTOR** (jstor.org) - Academic journals and primary sources
- **Web of Science** - Citation database for scientific research
- **Semantic Scholar** (semanticscholar.org) - AI-powered research tool
- **IEEE Xplore** - Engineering, computer science, and electronics

### Institutional Sources
- **University research repositories** - Institution-specific research databases
- **National libraries** - Government-maintained scholarly collections
- **Research institution publications** - Think tanks and research centers

## Government and Official Statistics

### Government Databases
- **Data.gov** - US government open data
- **Census Bureau** (census.gov) - US demographic and economic data
- **Bureau of Labor Statistics** (bls.gov) - Employment, inflation, economic indicators
- **CDC** (cdc.gov) - Health statistics and disease information
- **FDA** (fda.gov) - Drug, food, and medical device information
- **EPA** (epa.gov) - Environmental data and regulations
- **National Archives** - Historical government documents

### International Organizations
- **World Bank** (worldbank.org) - Global development data
- **WHO** (who.int) - Global health information
- **UN Statistics** (unstats.un.org) - International demographic and economic data
- **OECD** (oecd.org) - Economic and social statistics
- **IMF** (imf.org) - Financial and economic data

## Fact-Checking Organizations

### Tier 1 Fact-Checkers (Highest Reliability)
- **Snopes** (snopes.com) - General fact-checking, claims verification
- **PolitiFact** (politifact.com) - Political claims, Truth-O-Meter ratings
- **FactCheck.org** (factcheck.org) - Political and policy claims
- **Reuters Fact Check** (reuters.com/fact-check) - News and viral claims
- **AP Fact Check** (apnews.com/ap-fact-check) - News verification
- **Full Fact** (fullfact.org) - UK-focused fact-checking

### International Fact-Checkers
- **Africa Check** - African continent fact-checking
- **Chequeado** - Latin American fact-checking
- **Les Décodeurs** (Le Monde) - French fact-checking
- **Correctiv** - German investigative journalism and fact-checking

## Reputable News Organizations

### Tier 1 (Highest Editorial Standards)
- **Associated Press** (AP)
- **Reuters**
- **BBC News**
- **The New York Times**
- **The Washington Post**
- **The Wall Street Journal**
- **The Guardian**
- **Financial Times**
- **NPR**
- **PBS NewsHour**

### Tier 2 (Strong Editorial Standards)
- **The Economist**
- **The Atlantic**
- **ProPublica** (investigative journalism)
- **Bloomberg News**
- **Los Angeles Times**
- **The Boston Globe**
- **USA Today**

## Specialized Domain Sources

### Medical and Health
- **The Lancet** - Medical journal
- **New England Journal of Medicine** - Medical research
- **JAMA** - Journal of the American Medical Association
- **Mayo Clinic** - Medical information
- **Johns Hopkins Medicine** - Health information and research

### Science and Technology
- **Nature** - Scientific journal
- **Science** - Scientific journal (AAAS)
- **Scientific American** - Science journalism
- **MIT Technology Review** - Technology analysis
- **Ars Technica** - Technology news and analysis

### Legal and Policy
- **Supreme Court Database** - Legal decisions
- **Congressional Record** - Legislative proceedings
- **Federal Register** - Federal regulations
- **Think tanks** - Brookings Institution, RAND Corporation, Council on Foreign Relations

### Economics and Business
- **Federal Reserve** - Economic data and research
- **National Bureau of Economic Research** - Economic research
- **World Economic Forum** - Economic analysis

## Source Quality Criteria

### Credibility Indicators
1. **Peer review status** - Has the work been peer-reviewed?
2. **Author credentials** - What are the author's qualifications and affiliations?
3. **Publication reputation** - What is the journal or publisher's impact factor?
4. **Methodology** - Is the research methodology sound and transparent?
5. **Citations** - How often is this source cited by others?
6. **Conflicts of interest** - Are potential biases disclosed?
7. **Replication** - Have the findings been replicated?
8. **Recency** - How current is the information?

### Red Flags
- Anonymous or unattributed sources
- Lack of citations or references
- Sensationalized headlines
- Partisan or advocacy websites without disclosure
- Unverifiable claims
- Poor grammar or unprofessional presentation
- Circular sourcing (sources citing each other)
- Cherry-picked data

## Domain-Specific Considerations

### Medical Claims
- Prioritize peer-reviewed medical journals
- Check for FDA approval status
- Verify with medical institutions (Mayo Clinic, Johns Hopkins)
- Be cautious of anecdotal evidence

### Scientific Claims
- Look for peer-reviewed publications
- Check for replication studies
- Verify methodology and sample sizes
- Consider scientific consensus

### Statistical Claims
- Verify with original data sources (government databases)
- Check methodology and sample sizes
- Look for margin of error
- Consider time period and context

### Historical Claims
- Verify with primary sources when possible
- Cross-reference with multiple historians
- Check archival records
- Consider historiographical debates

### Political Claims
- Use nonpartisan fact-checkers
- Verify with official government sources
- Check for context and full quotes
- Compare multiple news sources
